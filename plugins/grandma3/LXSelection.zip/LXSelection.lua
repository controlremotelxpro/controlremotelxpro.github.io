-- Set this to the OSC configuration line directed to LX Controller.
local outputLine = 1
-- Bit order is part of the v1 reply format.
local attributes = {"Dimmer", "Pan", "Tilt", "ColorRGB_R", "ColorRGB_G", "ColorRGB_B", "Zoom", "Focus", "Iris"}

return function(_, request)
    if type(request) ~= "string" or #request ~= 16 or not request:match("^%x+$") then return end
    local address = "/lx/selection/v1/" .. request
    local rows = {}
    local index = SelectionFirst()
    while index ~= nil and #rows < 32 do
        local mask = 0
        for bit, name in ipairs(attributes) do
            local attribute = GetAttributeIndex(name)
            if attribute ~= nil and GetUIChannelIndex(index, attribute) ~= nil then
                mask = mask + 2 ^ (bit - 1)
            end
        end
        local fixture = GetSubfixture(index)
        local fid = fixture and tostring(fixture.FID) or ""
        if not fid:match("^%d+$") or #fid > 9 then fid = "0" end
        rows[#rows + 1] = string.format("%d/%s/%d", index, fid, mask)
        index = SelectionNext(index)
    end
    local state = index ~= nil and "partial" or "complete"
    Cmd(string.format('SendOSC %d "%s,s,%s|%s"', outputLine, address, state, table.concat(rows, ":")))
end
